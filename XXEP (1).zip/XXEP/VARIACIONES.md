# Posibles modificaciones del examen y cómo resolverlas

Regla: casi siempre cambian (a) entidad/campos, (b) roles, (c) la consulta del reporte, (d) mensajes y rutas.

## 1. Cambiar roles / rutas
- Rol distinto: `@PreAuthorize("hasRole('ANALISTA')")` y que exista en `roles` y en `user_role` (data-inicial.sql).
- Varios roles: `@PreAuthorize("hasAnyRole('ADMIN','ANALISTA')")`
- Cualquier logueado: `@PreAuthorize("isAuthenticated()")`
- Con prefijo explícito: `hasAuthority('ROLE_CLIENTE')`
- Crear un usuario nuevo: INSERT en `users` + INSERT en `user_role` (password BCrypt de 12345 ya incluido).
- Otra ruta: cambia solo `@RequestMapping` / `@PostMapping` / `@GetMapping`.

## 2. Cambiar qué campos son obligatorios (PagoRequestDTO)
- Obligatorio: `@NotNull` (números/objetos) o `@NotBlank` (texto). Opcional: sin anotación.
- Además marca `nullable = false` en la entidad si el campo es NOT NULL en la BD.
- Valores permitidos: `@Pattern(regexp = "TARJETA|YAPE|EFECTIVO")`. Rango: `@Min(1)`, `@Positive`.
- Valor por defecto cuando es opcional: en el servicio `x != null ? x : valorPorDefecto`.

## 3. Cambiar el reporte (HU03) — solo cambia el @Query
Ya están en `PagoRepository`: por día (cantidad / suma), por método (cantidad / suma), por mes.
Más ejemplos:
```java
// Pagos de un solo método: cantidad por día
@Query("SELECT p.fechaPago, COUNT(p) FROM Pago p WHERE p.metodo = :metodo GROUP BY p.fechaPago")
List<Object[]> contarPorDiaYMetodo(@Param("metodo") String metodo);

// Entre fechas
@Query("SELECT p.fechaPago, COUNT(p) FROM Pago p WHERE p.fechaPago BETWEEN :ini AND :fin GROUP BY p.fechaPago")
List<Object[]> contarEntre(@Param("ini") LocalDate ini, @Param("fin") LocalDate fin);

// Monto mayor a X
@Query("SELECT p.fechaPago, COUNT(p) FROM Pago p WHERE p.monto > :min GROUP BY p.fechaPago")
List<Object[]> contarMayoresA(@Param("min") Double min);

// Por estado del pedido (JOIN por la relación)
@Query("SELECT p.pedido.estado, COUNT(p) FROM Pago p GROUP BY p.pedido.estado")
List<Object[]> contarPorEstadoPedido();

// Pagos de un cliente
@Query("SELECT p FROM Pago p WHERE p.pedido.cliente = :cliente")
List<Pago> pagosDeCliente(@Param("cliente") String cliente);

// Promedio / máximo
@Query("SELECT p.metodo, AVG(p.monto) FROM Pago p GROUP BY p.metodo")
@Query("SELECT MAX(p.monto) FROM Pago p")
```
Tipos de retorno por fila (Object[]): `COUNT` -> Long, `SUM/AVG` de Double -> Double, `MONTH()` -> Integer,
campo String -> String, campo LocalDate -> LocalDate. Castea con el tipo correcto en el servicio.

### Reporte por método ya listo (solo falta exponerlo)
```java
@PreAuthorize("hasRole('ADMIN')")
@GetMapping("/metodos/YYY")
public ResponseEntity<?> prlaPorMetodo() {
    var lista = prlaService.prlaReportePorMetodo();
    return lista.isEmpty() ? ResponseEntity.ok("No existen pagos registrados") : ResponseEntity.ok(lista);
}
```

### Filtro por parámetro (query param / path variable)
```java
@GetMapping("/YYY")                                   // GET /cantidades/YYY?metodo=YAPE
public ResponseEntity<?> filtrar(@RequestParam String metodo) { ... }

@GetMapping("/YYY/{fecha}")                           // GET /cantidades/YYY/2025-01-15
public ResponseEntity<?> porFecha(@PathVariable LocalDate fecha) { ... }
```

## 4. Cambiar la entidad principal / FK (ej. Pago -> Venta, Pedido -> Cliente)
1. Renombra la entidad, su repositorio, DTOs, servicio y controller (IntelliJ: Shift+F6).
2. FK: cambia `@ManyToOne` + `@JoinColumn(name="id_xxx")` y el `findById` del servicio.
3. Actualiza el SQL de datos de prueba (nombres de columna en snake_case: `codigo_pedido`).
4. Si la FK es obligatoria, valida el id en el DTO (`@NotNull`) y lanza `RecursoNoEncontradoException`.

## 5. Otras operaciones que pueden pedir
```java
// GET listar todos            -> prlaPagoRepo.findAll()
// GET por id                  -> prlaPagoRepo.findById(id).orElseThrow(...)
// PUT actualizar              -> buscar, setear campos, save()
// DELETE                      -> prlaPagoRepo.deleteById(id)
// POST registrar pedido       -> igual a HU02 pero con Pedido (código único: valida existsByCodigoPedido)
// Evitar código duplicado     -> en el repo: boolean existsByCodigoConfirmacion(String c);
//                                en el servicio: if (existe) throw new IllegalArgumentException("Código ya existe");
//                                y en el ManejadorGlobalExcepciones un @ExceptionHandler(IllegalArgumentException) -> 400
```
Códigos HTTP: crear -> `ResponseEntity.status(HttpStatus.CREATED).body(...)` (201); no encontrado -> 404; validación -> 400.

## 6. Mensajes exactos que suelen pedir
- POST ok: `"Se registró correctamente con ID " + id`
- GET vacío: `"No existen pagos registrados"`
- FK inexistente: `"Pedido no encontrado"`
Copia el texto tal cual del enunciado (tildes y mayúsculas incluidas).

## 7. Convenciones del enunciado (descuentan puntos)
- Proyecto `ApellidoPaterno+EP` (PerezEP) y BD `base+ApellidoPaterno+EP` (basePerezEP).
- Variables: iniciales + camelCase (`prlaService`, `prlaDto`). Aquí se aplicó a variables/métodos propios;
  los campos de las entidades se dejaron como pide el modelo (idPago, monto...). Si tu profesor exige prefijo
  también en los atributos de las entidades, cámbialos (ojo: cambia el JSON y el nombre de columna).
- Paquetes: iniciales + capa (`prlaentities`, `prlacontrollers`, `prlaservices`, `prlarepositories`, `prladto`, `prlasecurity`).
- Ruta de los controllers: apellidoPaterno (puedes agregar frases: `/pagos/perez`).

## 8. Errores típicos
- 401 en un endpoint protegido: falta el token o no diste Authorize en Swagger.
- 403: el usuario no tiene el rol (revisa user_role y que el nombre coincida SIN "ROLE_").
- `relation "users" does not exist`: corriste el SQL antes de levantar la app una vez.
- `ERROR: duplicate key ... codigo_confirmacion`: repetiste el código único.
- `jwt.secret` con menos de 32 caracteres: JWT lanza WeakKeyException.
- Paquetes no encontrados (No qualifying bean / Not a managed type): revisa el escaneo en la clase principal.
- Hash BCrypt: debe ser `$2a$10$...` completo (60 caracteres) o el login falla.
