# XXEP – GoLima (Spring Boot + JWT + PostgreSQL)

## Reemplazos (Buscar y reemplazar en todo el proyecto, Ctrl+Shift+R)
| Placeholder | Significado | Ejemplo |
|---|---|---|
| XXX | apellido paterno (ruta POST) | perez |
| YYY | apellido materno (ruta GET) | reyes |
| prla | iniciales (apellidos+nombres) | prla (Luis Angel Perez Reyes) |
| XXEP | nombre del proyecto | PerezEP |
| baseXXEP | nombre de la BD | basePerezEP |

Al cambiar `prla`, renombra también los paquetes (prlaentities -> tuinicialesentities, etc.) y las anotaciones
@SpringBootApplication/@EntityScan/@EnableJpaRepositories de la clase principal (IntelliJ: Shift+F6 sobre el paquete).

## Pasos
1. Crear la BD `baseXXEP` en PostgreSQL; ajustar usuario/clave en application.properties.
2. Ejecutar la app una vez (crea tablas) -> detenerla -> ejecutar `src/main/resources/data-inicial.sql`.
3. Swagger: http://localhost:8080/swagger-ui.html
   - HU01: POST /ingresos {"username":"cliente","password":"12345"} -> token -> botón Authorize
   - HU02: POST /pagos/XXX (CLIENTE)
   - HU03: GET /cantidades/YYY (ADMIN; entrar con username "admin")
4. Pruebas negativas: sin token -> 401; token de CLIENTE en el GET -> 403.

Ver VARIACIONES.md para las modificaciones posibles del examen.
