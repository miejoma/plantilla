-- EJECUTAR DESPUÉS de levantar la app una vez (Hibernate crea las tablas) y detenerla.

-- 1) Roles (SIN el prefijo ROLE_; el prefijo lo agrega JwtUserDetailsService)
INSERT INTO roles(name) VALUES ('ADMIN'), ('CLIENTE'), ('REPARTIDOR'), ('ANALISTA'), ('SOPORTE');

-- 2) Usuarios. Password de todos = 12345 (encriptado con BCrypt)
INSERT INTO users(username, password, enabled) VALUES
  ('admin',   '$2a$10$pQeZla3780Hhi38rLnuRvuJuppfpE0EVeFQ5xFLEvEWKzNzpgzv4.', true),
  ('cliente', '$2a$10$pQeZla3780Hhi38rLnuRvuJuppfpE0EVeFQ5xFLEvEWKzNzpgzv4.', true);

-- 3) Relación usuario-rol (tabla intermedia user_role)
INSERT INTO user_role(user_id, role_id) VALUES
  ((SELECT id FROM users WHERE username='admin'),   (SELECT id FROM roles WHERE name='ADMIN')),
  ((SELECT id FROM users WHERE username='cliente'), (SELECT id FROM roles WHERE name='CLIENTE'));

-- 4) Datos de prueba: pedidos (el pago necesita un pedido existente por la FK)
INSERT INTO pedido (codigo_pedido, fecha_emision, estado, repartidor, cliente, total) VALUES
  ('PED-001', '2025-01-15', 'PENDIENTE', 'Juan',  'Maria', 50.0),
  ('PED-002', '2025-01-16', 'ENTREGADO', 'Pedro', 'Luis',  80.0);
