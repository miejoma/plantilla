package prlaservices;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import prladto.*;
import prlaentities.*;
import prlaexceptions.RecursoNoEncontradoException;
import prlarepositories.*;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.*;

/** Lógica de negocio. El controller solo recibe/devuelve; aquí se arma y guarda todo. */
@Service
@RequiredArgsConstructor   // Lombok: crea el constructor con los campos final (inyección de dependencias)
public class PagoService {

    private final PagoRepository prlaPagoRepo;
    private final PedidoRepository prlaPedidoRepo;

    // ===== HU02: registrar pago =====
    public PagoResponseDTO prlaRegistrar(PagoRequestDTO prlaDto) {
        // 1. Buscar el pedido de la FK; si no existe, error 404
        Pedido prlaPedido = prlaPedidoRepo.findById(prlaDto.getIdPedido())
                .orElseThrow(() -> new RecursoNoEncontradoException("Pedido no encontrado"));

        // 2. Armar la entidad desde el DTO. Fecha/hora opcionales: si no vienen, se usa la actual
        Pago prlaPago = Pago.builder()
                .monto(prlaDto.getMonto())
                .metodo(prlaDto.getMetodo())
                .codigoConfirmacion(prlaDto.getCodigoConfirmacion())
                .fechaPago(prlaDto.getFechaPago() != null ? prlaDto.getFechaPago() : LocalDate.now())
                .horaPago(prlaDto.getHoraPago() != null ? prlaDto.getHoraPago() : LocalTime.now())
                .pedido(prlaPedido)
                .build();

        // 3. Guardar (INSERT) y devolver el mensaje con el ID generado
        Pago prlaGuardado = prlaPagoRepo.save(prlaPago);
        return PagoResponseDTO.builder()
                .idPago(prlaGuardado.getIdPago())
                .mensaje("Se registró correctamente con ID " + prlaGuardado.getIdPago())
                .build();
    }

    // ===== HU03: cantidad de pagos por día =====
    public List<CantidadPagoDTO> prlaContarPorDia() {
        List<CantidadPagoDTO> prlaLista = new ArrayList<>();
        // Cada fila del @Query es un Object[]: [0] = fecha, [1] = cantidad (COUNT devuelve Long)
        for (Object[] prlaFila : prlaPagoRepo.prlaContarPorDia()) {
            prlaLista.add(CantidadPagoDTO.builder()
                    .fecha((LocalDate) prlaFila[0])
                    .cantidad((Long) prlaFila[1])
                    .build());
        }
        return prlaLista;
    }

    // ===== (Variación) reporte por método: cantidad y monto total =====
    public List<ReportePagoMetodoDTO> prlaReportePorMetodo() {
        Map<String, Long> prlaCantidades = new LinkedHashMap<>();
        for (Object[] f : prlaPagoRepo.prlaContarPorMetodo()) prlaCantidades.put((String) f[0], (Long) f[1]);

        List<ReportePagoMetodoDTO> prlaLista = new ArrayList<>();
        for (Object[] f : prlaPagoRepo.prlaSumarPorMetodo()) {
            String prlaMetodo = (String) f[0];
            prlaLista.add(ReportePagoMetodoDTO.builder()
                    .metodo(prlaMetodo)
                    .cantidad(prlaCantidades.get(prlaMetodo))
                    .montoTotal((Double) f[1])   // SUM de Double devuelve Double
                    .build());
        }
        return prlaLista;
    }
}
