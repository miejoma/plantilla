package prladto;

import lombok.*;

/** (Variación) Fila de reporte por método: método + cantidad + monto total. */
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class ReportePagoMetodoDTO {
    private String metodo;
    private Long cantidad;
    private Double montoTotal;
}
