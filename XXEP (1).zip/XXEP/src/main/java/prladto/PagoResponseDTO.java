package prladto;

import lombok.*;

/** Datos que SALEN del POST: el ID generado y el mensaje de éxito. */
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class PagoResponseDTO {
    private Long idPago;
    private String mensaje;
}
