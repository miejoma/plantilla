package prladto;

import lombok.*;
import java.time.LocalDate;

/** Fila del reporte HU03: fecha + cantidad de pagos de ese día. */
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class CantidadPagoDTO {
    private LocalDate fecha;
    private Long cantidad;
}
