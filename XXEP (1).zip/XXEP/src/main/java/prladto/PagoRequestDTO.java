package prladto;

import jakarta.validation.constraints.*;
import lombok.*;
import java.time.LocalDate;
import java.time.LocalTime;

/**
 * Datos que ENTRAN en el POST. Solo 4 obligatorios (los demás son opcionales).
 * SUPUESTO: el enunciado dice "4 campos obligatorios" pero solo marca 2 en el modelo; aquí se toman
 * monto, metodo, codigoConfirmacion e idPedido. Si el examen indica otros, mueve las anotaciones @NotNull.
 */
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class PagoRequestDTO {

    @NotNull(message = "El monto es obligatorio")
    @Positive(message = "El monto debe ser mayor a 0")
    private Double monto;

    @NotBlank(message = "El método es obligatorio")
    @Pattern(regexp = "TARJETA|YAPE|EFECTIVO", message = "Método válido: TARJETA, YAPE o EFECTIVO")
    private String metodo;

    @NotBlank(message = "El código de confirmación es obligatorio")
    private String codigoConfirmacion;

    @NotNull(message = "El idPedido es obligatorio")
    private Long idPedido;

    // Opcionales
    private LocalDate fechaPago;
    private LocalTime horaPago;
}
