package prlarepositories;

import org.springframework.data.jpa.repository.JpaRepository;
import prlaentities.Pedido;

/** CRUD de Pedido ya incluido (save, findById, findAll, deleteById...). */
public interface PedidoRepository extends JpaRepository<Pedido, Long> { }
