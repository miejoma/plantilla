package prlarepositories;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import prlaentities.Pago;
import java.time.LocalDate;
import java.util.List;

public interface PagoRepository extends JpaRepository<Pago, Long> {

    // ===== HU03: cantidad de pagos por día =====
    // JPQL (usa nombres de la CLASE y sus atributos, no de la tabla).
    // Devuelve filas [fecha, cantidad].
    @Query("SELECT p.fechaPago, COUNT(p) FROM Pago p GROUP BY p.fechaPago ORDER BY p.fechaPago")
    List<Object[]> prlaContarPorDia();

    // ===== POSIBLES VARIACIONES (el enunciado menciona reportes por día y por método) =====

    // Cantidad de pagos por método (TARJETA / YAPE / EFECTIVO)
    @Query("SELECT p.metodo, COUNT(p) FROM Pago p GROUP BY p.metodo")
    List<Object[]> prlaContarPorMetodo();

    // Suma de montos por método
    @Query("SELECT p.metodo, SUM(p.monto) FROM Pago p GROUP BY p.metodo")
    List<Object[]> prlaSumarPorMetodo();

    // Suma de montos por día
    @Query("SELECT p.fechaPago, SUM(p.monto) FROM Pago p GROUP BY p.fechaPago ORDER BY p.fechaPago")
    List<Object[]> prlaSumarPorDia();

    // Cantidad por mes
    @Query("SELECT MONTH(p.fechaPago), COUNT(p) FROM Pago p GROUP BY MONTH(p.fechaPago) ORDER BY MONTH(p.fechaPago)")
    List<Object[]> prlaContarPorMes();

    // Método derivado (Spring arma la consulta por el nombre): pagos de un método / de una fecha
    List<Pago> findByMetodo(String metodo);
    List<Pago> findByFechaPago(LocalDate fecha);
}
