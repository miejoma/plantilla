package prlaconfig;

import io.swagger.v3.oas.models.*;
import io.swagger.v3.oas.models.security.*;
import org.springframework.context.annotation.*;

/** Configura Swagger para que muestre el botón "Authorize" y envíe el token JWT (Bearer). */
@Configuration
public class OpenApiConfig {

    @Bean
    public OpenAPI prlaOpenAPI() {
        return new OpenAPI()
            // Exige el esquema "bearerAuth" en todos los endpoints documentados
            .addSecurityItem(new SecurityRequirement().addList("bearerAuth"))
            // Define el esquema: HTTP Bearer con formato JWT
            .components(new Components().addSecuritySchemes("bearerAuth",
                new SecurityScheme()
                    .type(SecurityScheme.Type.HTTP)
                    .scheme("bearer")
                    .bearerFormat("JWT")));
    }
}
