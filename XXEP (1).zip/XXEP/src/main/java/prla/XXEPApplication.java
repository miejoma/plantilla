package prla;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

/**
 * Clase principal. Como los paquetes se llaman prlaentities, prlaservices... (convención del
 * examen) y NO son subpaquetes de "prla", hay que decirle a Spring dónde buscar cada cosa.
 * Si usas subpaquetes (prla.entities...) puedes borrar estas 3 anotaciones de escaneo.
 */
@SpringBootApplication(scanBasePackages = {
        "prlacontrollers", "prlaservices", "prlasecurity", "prlaconfig", "prlaexceptions"})
@EntityScan({"prlaentities", "prlasecurity"})                       // dónde están las @Entity
@EnableJpaRepositories({"prlarepositories", "prlasecurity"})        // dónde están los JpaRepository
public class XXEPApplication {
    public static void main(String[] args) {
        SpringApplication.run(XXEPApplication.class, args);
    }
}
