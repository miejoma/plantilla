package prlasecurity;

import lombok.RequiredArgsConstructor;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.config.annotation.authentication.configuration.AuthenticationConfiguration;
import org.springframework.security.config.annotation.method.configuration.EnableMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;

/** Configuración central de seguridad. */
@Configuration
@EnableWebSecurity
@EnableMethodSecurity   // activa @PreAuthorize en los controllers
@RequiredArgsConstructor
public class WebSecurityConfig {

    private final JwtAuthenticationEntryPoint prlaEntryPoint;
    private final JwtRequestFilter prlaRequestFilter;

    // Compara el password enviado con el hash BCrypt guardado en la BD
    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }

    // Lo usa AuthController para validar username/password en el login
    @Bean
    public AuthenticationManager authenticationManager(AuthenticationConfiguration cfg) throws Exception {
        return cfg.getAuthenticationManager();
    }

    @Bean
    public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
        http.csrf(csrf -> csrf.disable())   // API REST con token: no se usa CSRF
            .authorizeHttpRequests(auth -> auth
                // Rutas públicas: login y Swagger
                .requestMatchers("/ingresos", "/swagger-ui/**", "/swagger-ui.html", "/v3/api-docs/**").permitAll()
                // Todo lo demás exige token
                .anyRequest().authenticated())
            .exceptionHandling(ex -> ex.authenticationEntryPoint(prlaEntryPoint))
            // Sin sesiones: cada petición trae su token
            .sessionManagement(s -> s.sessionCreationPolicy(SessionCreationPolicy.STATELESS))
            // Nuestro filtro JWT corre antes del filtro de login estándar
            .addFilterBefore(prlaRequestFilter, UsernamePasswordAuthenticationFilter.class);
        return http.build();
    }
}
