package prlasecurity;

import jakarta.persistence.*;
import lombok.*;
import java.util.HashSet;
import java.util.Set;

/**
 * Tabla "users". Se llama "users" (no "user") porque USER es palabra reservada en PostgreSQL.
 * Un usuario puede tener varios roles (N:M) mediante la tabla intermedia user_role.
 */
@Entity
@Table(name = "users")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor
public class User {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;

    @Column(name = "username", unique = true, nullable = false)
    private String username;

    // Guarda el hash BCrypt, nunca la contraseña en texto plano
    @Column(name = "password", nullable = false)
    private String password;

    // Si es false, Spring Security no deja ingresar al usuario.
    // Se usa el wrapper Boolean (no boolean) para evitar errores al leer filas con NULL.
    @Column(name = "enabled", nullable = false)
    private Boolean enabled = true;

    // EAGER: los roles se cargan junto con el usuario (necesario porque el filtro JWT
    // los lee fuera de una transacción; con LAZY daría LazyInitializationException).
    @ManyToMany(fetch = FetchType.EAGER)
    @JoinTable(name = "user_role",
            joinColumns = @JoinColumn(name = "user_id"),
            inverseJoinColumns = @JoinColumn(name = "role_id"))
    private Set<Role> roles = new HashSet<>();
}
