package prlasecurity;

import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.*;
import java.util.Map;

/** HU01: genera el token. Ruta pública: POST /ingresos */
@RestController
@RequiredArgsConstructor
public class AuthController {

    private final AuthenticationManager prlaAuthManager;
    private final JwtUserDetailsService prlaUserDetailsService;
    private final JwtTokenUtil prlaJwtTokenUtil;

    // Body esperado: {"username":"admin","password":"12345"}
    @PostMapping("/ingresos")
    public ResponseEntity<?> prlaLogin(@RequestBody Map<String, String> prlaBody) {
        String prlaUsername = prlaBody.get("username");
        String prlaPassword = prlaBody.get("password");
        try {
            // Verifica usuario y password (contra el hash BCrypt de la BD)
            prlaAuthManager.authenticate(new UsernamePasswordAuthenticationToken(prlaUsername, prlaPassword));
        } catch (Exception e) {
            return ResponseEntity.status(401).body("Credenciales inválidas");
        }
        // Credenciales correctas: se genera y devuelve el token
        UserDetails prlaUd = prlaUserDetailsService.loadUserByUsername(prlaUsername);
        return ResponseEntity.ok(Map.of("token", prlaJwtTokenUtil.generateToken(prlaUd)));
    }
}
