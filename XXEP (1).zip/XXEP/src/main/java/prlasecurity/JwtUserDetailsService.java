package prlasecurity;

import lombok.RequiredArgsConstructor;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;
import java.util.List;

/** Le enseña a Spring Security a buscar usuarios en NUESTRA base de datos. */
@Service
@RequiredArgsConstructor
public class JwtUserDetailsService implements UserDetailsService {

    private final UserRepository prlaUserRepository;

    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        User prlaUser = prlaUserRepository.findByUsername(username)
                .orElseThrow(() -> new UsernameNotFoundException("Usuario no encontrado: " + username));

        // Se antepone ROLE_ a cada rol para que hasRole('CLIENTE') funcione
        List<GrantedAuthority> prlaAuthorities = prlaUser.getRoles().stream()
                .map(r -> (GrantedAuthority) new SimpleGrantedAuthority("ROLE_" + r.getName()))
                .toList();

        // Se usa el nombre completo de la clase User de Spring para no chocar con nuestra User
        return new org.springframework.security.core.userdetails.User(
                prlaUser.getUsername(), prlaUser.getPassword(),
                Boolean.TRUE.equals(prlaUser.getEnabled()),   // enabled
                true, true, true,                              // cuenta/credenciales no expiradas ni bloqueadas
                prlaAuthorities);
    }
}
