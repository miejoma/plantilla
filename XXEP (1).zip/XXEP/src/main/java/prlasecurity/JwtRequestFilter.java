package prlasecurity;

import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import lombok.RequiredArgsConstructor;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.web.authentication.WebAuthenticationDetailsSource;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;
import java.io.IOException;

/** Filtro que corre en CADA petición: lee "Authorization: Bearer <token>" y autentica al usuario. */
@Component
@RequiredArgsConstructor
public class JwtRequestFilter extends OncePerRequestFilter {

    private final JwtUserDetailsService prlaUserDetailsService;
    private final JwtTokenUtil prlaJwtTokenUtil;

    @Override
    protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response,
                                    FilterChain chain) throws ServletException, IOException {
        String prlaHeader = request.getHeader("Authorization");

        if (prlaHeader != null && prlaHeader.startsWith("Bearer ")) {
            String prlaToken = prlaHeader.substring(7);   // quita "Bearer "
            try {
                String prlaUsername = prlaJwtTokenUtil.getUsernameFromToken(prlaToken);
                if (prlaUsername != null && SecurityContextHolder.getContext().getAuthentication() == null) {
                    UserDetails prlaUd = prlaUserDetailsService.loadUserByUsername(prlaUsername);
                    if (prlaJwtTokenUtil.validateToken(prlaToken, prlaUd)) {
                        // Token OK: se registra al usuario (y sus roles) como autenticado en esta petición
                        UsernamePasswordAuthenticationToken prlaAuth =
                                new UsernamePasswordAuthenticationToken(prlaUd, null, prlaUd.getAuthorities());
                        prlaAuth.setDetails(new WebAuthenticationDetailsSource().buildDetails(request));
                        SecurityContextHolder.getContext().setAuthentication(prlaAuth);
                    }
                }
            } catch (Exception e) {
                // Token inválido/expirado: no se autentica -> el EntryPoint responde 401
            }
        }
        chain.doFilter(request, response);   // continúa con el resto de filtros
    }
}
