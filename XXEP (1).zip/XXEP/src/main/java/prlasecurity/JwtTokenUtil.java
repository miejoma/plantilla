package prlasecurity;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.security.Keys;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Component;
import javax.crypto.SecretKey;
import java.nio.charset.StandardCharsets;
import java.util.Date;

/** Crea y valida tokens JWT (firmados con HMAC usando jwt.secret). */
@Component
public class JwtTokenUtil {

    private static final long VALIDEZ_MS = 5 * 60 * 60 * 1000L;   // el token dura 5 horas

    private final SecretKey prlaKey;

    public JwtTokenUtil(@Value("${jwt.secret}") String secret) {
        this.prlaKey = Keys.hmacShaKeyFor(secret.getBytes(StandardCharsets.UTF_8));
    }

    // Genera el token: guarda el username (subject), fecha de emisión y de expiración
    public String generateToken(UserDetails userDetails) {
        Date ahora = new Date();
        return Jwts.builder()
                .subject(userDetails.getUsername())
                .issuedAt(ahora)
                .expiration(new Date(ahora.getTime() + VALIDEZ_MS))
                .signWith(prlaKey)
                .compact();
    }

    // Lee el contenido del token (lanza excepción si la firma es falsa o ya expiró)
    private Claims getClaims(String token) {
        return Jwts.parser().verifyWith(prlaKey).build().parseSignedClaims(token).getPayload();
    }

    public String getUsernameFromToken(String token) {
        return getClaims(token).getSubject();
    }

    // Válido = el usuario coincide y no expiró
    public boolean validateToken(String token, UserDetails userDetails) {
        try {
            Claims c = getClaims(token);
            return c.getSubject().equals(userDetails.getUsername()) && c.getExpiration().after(new Date());
        } catch (Exception e) {
            return false;
        }
    }
}
