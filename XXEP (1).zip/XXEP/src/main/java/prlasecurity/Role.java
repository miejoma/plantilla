package prlasecurity;

import jakarta.persistence.*;
import lombok.*;

/** Tabla "roles": ADMIN, CLIENTE, REPARTIDOR, ANALISTA, SOPORTE (se insertan por SQL). */
@Entity
@Table(name = "roles")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor
public class Role {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;

    @Column(name = "name", unique = true, nullable = false)
    private String name;     // sin prefijo ROLE_
}
