package prlacontrollers;

import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;
import prladto.CantidadPagoDTO;
import prlaservices.PagoService;
import java.util.List;

/** HU03. Ruta: /cantidades/YYY (apellido materno) */
@RestController
@RequestMapping("/cantidades")
@RequiredArgsConstructor
public class CantidadController {

    private final PagoService prlaService;

    @PreAuthorize("hasRole('ADMIN')")   // solo ADMIN
    @GetMapping("/YYY")
    public ResponseEntity<?> prlaCantidades() {
        List<CantidadPagoDTO> prlaLista = prlaService.prlaContarPorDia();
        // Si no hay pagos, el enunciado pide exactamente este mensaje
        if (prlaLista.isEmpty()) {
            return ResponseEntity.ok("No existen pagos registrados");
        }
        return ResponseEntity.ok(prlaLista);
    }
}
