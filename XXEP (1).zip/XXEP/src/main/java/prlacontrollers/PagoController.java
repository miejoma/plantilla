package prlacontrollers;

import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;
import prladto.*;
import prlaservices.PagoService;

/** HU02. Ruta base /pagos + /apellidoPaterno  ->  /pagos/XXX */
@RestController
@RequestMapping("/pagos")
@RequiredArgsConstructor
public class PagoController {

    private final PagoService prlaService;

    // Solo usuarios con rol CLIENTE (hasRole busca la autoridad ROLE_CLIENTE).
    // Sin token -> 401. Con token de otro rol -> 403.
    @PreAuthorize("hasRole('CLIENTE')")
    @PostMapping("/XXX")
    public ResponseEntity<PagoResponseDTO> prlaRegistrar(@Valid @RequestBody PagoRequestDTO prlaDto) {
        // @Valid activa las validaciones del DTO (campos obligatorios, método válido)
        return ResponseEntity.ok(prlaService.prlaRegistrar(prlaDto));
    }
}
