package prlaexceptions;

/** Excepción propia: se lanza cuando no existe un registro (ej. el pedido de la FK). */
public class RecursoNoEncontradoException extends RuntimeException {
    public RecursoNoEncontradoException(String mensaje) {
        super(mensaje);
    }
}
