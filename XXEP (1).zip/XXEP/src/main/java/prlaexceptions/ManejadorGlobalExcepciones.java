package prlaexceptions;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * Convierte excepciones en respuestas JSON claras.
 * OJO: NO se captura RuntimeException genérica, porque AccessDeniedException (el 403 de
 * @PreAuthorize) también es RuntimeException y dejaría de devolver 403.
 */
@RestControllerAdvice
public class ManejadorGlobalExcepciones {

    // Pedido inexistente -> 404
    @ExceptionHandler(RecursoNoEncontradoException.class)
    public ResponseEntity<Map<String, String>> noEncontrado(RecursoNoEncontradoException ex) {
        return ResponseEntity.status(HttpStatus.NOT_FOUND).body(Map.of("mensaje", ex.getMessage()));
    }

    // Falla una validación del DTO (campo obligatorio faltante, método inválido...) -> 400
    @ExceptionHandler(MethodArgumentNotValidException.class)
    public ResponseEntity<Map<String, String>> validacion(MethodArgumentNotValidException ex) {
        Map<String, String> errores = ex.getBindingResult().getFieldErrors().stream()
                .collect(Collectors.toMap(e -> e.getField(), e -> String.valueOf(e.getDefaultMessage()),
                        (a, b) -> a));
        return ResponseEntity.badRequest().body(errores);
    }
}
