package prlaentities;

import jakarta.persistence.*;
import lombok.*;
import java.time.LocalDate;

/** Tabla "pedido". Es el lado "uno" de la relación Pedido 1 - N Pago. */
@Entity
@Table(name = "pedido")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder   // Lombok: getters, setters, constructores, builder
public class Pedido {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)   // autoincremental (serial en PostgreSQL)
    private Long idPedido;

    @Column(unique = true, nullable = false)              // código único y obligatorio
    private String codigoPedido;

    private LocalDate fechaEmision;
    private String estado;        // PENDIENTE, ENTREGADO, CANCELADO
    private String repartidor;
    private String cliente;
    private Double total;
}
