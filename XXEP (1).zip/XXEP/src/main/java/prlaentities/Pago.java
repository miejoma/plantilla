package prlaentities;

import jakarta.persistence.*;
import lombok.*;
import java.time.LocalDate;
import java.time.LocalTime;

/** Tabla "pago". Cada pago pertenece a un pedido (FK id_pedido). */
@Entity
@Table(name = "pago")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class Pago {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long idPago;

    @Column(nullable = false)                 // obligatorio
    private Double monto;

    @Column(nullable = false)                 // obligatorio: TARJETA, YAPE o EFECTIVO
    private String metodo;

    @Column(unique = true)                    // no se puede repetir
    private String codigoConfirmacion;

    private LocalDate fechaPago;              // opcional (si no llega se usa hoy)
    private LocalTime horaPago;               // opcional (si no llega se usa ahora)

    // Llave foránea hacia Pedido: muchos pagos -> un pedido. Obligatoria.
    @ManyToOne
    @JoinColumn(name = "id_pedido", nullable = false)
    private Pedido pedido;
}
